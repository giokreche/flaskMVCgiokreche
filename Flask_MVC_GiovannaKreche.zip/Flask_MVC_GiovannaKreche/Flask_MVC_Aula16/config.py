import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # SQLite é usado como padrão para permitir testar o projeto imediatamente.
    # Para seguir a aula com PostgreSQL, configure DATABASE_URL no arquivo .env.
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "sqlite:///crud_mvc.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.getenv("SECRET_KEY", "chave-local-de-desenvolvimento")
