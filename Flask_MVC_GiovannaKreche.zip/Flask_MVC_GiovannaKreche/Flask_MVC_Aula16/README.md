# Projeto Flask MVC — Aula 16

Projeto didático de gerenciamento escolar, organizado conforme o PDF da Aula 16:
**Alunos, Disciplinas, Matrículas e consulta de alunos por disciplina**.

## Requisitos
- Python 3.10 ou superior
- pip
- Para usar PostgreSQL: PostgreSQL instalado e um banco criado no pgAdmin

## 1. Abrir a pasta e criar o ambiente virtual

No terminal do VS Code, dentro desta pasta:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

Se o PowerShell bloquear a ativação, execute uma vez:
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```
Depois tente ativar novamente.

## 2. Instalar as bibliotecas

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Configurar o banco de dados

### Opção A — testar rapidamente com SQLite
Não precisa criar banco nem configurar nada. O projeto usa SQLite automaticamente quando não encontra `DATABASE_URL`. Basta seguir para o passo 4.

### Opção B — PostgreSQL, como no exemplo da aula
1. Abra o pgAdmin e crie um banco chamado `CrudMvc`.
2. Copie `.env.example` e renomeie a cópia para `.env`.
3. Edite `DATABASE_URL` com o usuário, senha, host, porta e nome do seu banco. Exemplo:

```env
DATABASE_URL=postgresql://FlaskUser:12345@localhost:5432/CrudMvc
SECRET_KEY=coloque-uma-chave-secreta-aqui
```

Use os dados reais do PostgreSQL instalado no seu computador. O usuário `FlaskUser` e a senha `12345` são apenas exemplos do slide, não são criados automaticamente.

## 4. Criar as tabelas com Flask-Migrate

Execute na pasta principal do projeto, com o ambiente virtual ativado:

```powershell
flask --app run db init
flask --app run db migrate -m "Criar tabelas iniciais"
flask --app run db upgrade
```

**Atenção:** `db init` é executado somente na primeira vez. Depois que a pasta `migrations` existir, pule esse comando. Quando os models mudarem, execute novamente `migrate` e `upgrade`.

## 5. Iniciar o sistema

```powershell
python run.py
```

Abra no navegador: http://127.0.0.1:5000

Para encerrar, volte ao terminal e pressione `Ctrl + C`.

## O que testar no sistema
1. Entre em **Alunos** e cadastre dois alunos.
2. Entre em **Disciplinas** e cadastre duas disciplinas.
3. Entre em **Matrículas** e associe alunos às disciplinas.
4. Abra **Alunos por disciplina** e consulte uma disciplina.
5. Teste editar e excluir alunos e disciplinas e cancelar matrículas.

## Estrutura de pastas

```text
Flask_MVC_Aula16/
├── app/
│   ├── __init__.py
│   ├── forms.py
│   ├── controllers/
│   │   ├── index_controller.py
│   │   ├── aluno_controller.py
│   │   ├── disciplina_controller.py
│   │   ├── matricula_controller.py
│   │   └── alunos_por_disciplina_controller.py
│   ├── models/
│   │   └── models.py
│   ├── templates/
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── alunos/
│   │   ├── disciplinas/
│   │   ├── matriculas/
│   │   └── alunos_por_disciplina/
│   └── static/css/style.css
├── config.py
├── run.py
├── requirements.txt
└── .env.example
```

## Como o MVC aparece aqui?
- **Model:** `app/models/models.py` define Aluno, Disciplina e a associação entre eles.
- **View:** `app/templates/` contém as páginas HTML/Jinja que o navegador recebe.
- **Controller:** `app/controllers/` recebe as rotas, consulta os models e escolhe os templates.
- **Configuração:** `config.py` lê as variáveis do `.env`.
- **Inicialização:** `app/__init__.py` cria o Flask, o banco e o Flask-Migrate; `run.py` inicia o servidor.

## Observações
- Os formulários usam Flask-WTF, `validate_on_submit()` e token CSRF.
- Exclusões e cancelamentos usam POST, não links GET.
- A tabela `matriculas` é uma tabela intermediária N:N; não precisa de uma classe Model própria.
- O PDF menciona campos de foto como conteúdo de uma próxima aula. Eles não foram implementados nesta versão para manter o escopo da atividade atual.
- Bootstrap e Google Fonts são carregados por CDN; é necessária conexão com a internet para esses recursos visuais.
