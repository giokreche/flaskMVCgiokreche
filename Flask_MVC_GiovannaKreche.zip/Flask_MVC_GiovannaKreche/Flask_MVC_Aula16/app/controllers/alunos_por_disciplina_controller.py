from flask import render_template, redirect, url_for, flash
from app import app
from app.models.models import Disciplina
from app.forms import AlunosDisciplinaForm

@app.route("/alunos-por-disciplina", methods=["GET", "POST"])
def selecionar_disciplina():
    form = AlunosDisciplinaForm()
    if not form.disciplina_id.choices:
        flash("Cadastre uma disciplina primeiro.", "warning")
        return redirect(url_for("lista_disciplinas"))
    if form.validate_on_submit():
        return redirect(url_for("alunos_por_disciplina", id=form.disciplina_id.data))
    return render_template("alunos_por_disciplina/selecionar.html", form=form)

@app.route("/disciplinas/<int:id>/alunos")
def alunos_por_disciplina(id):
    disciplina = Disciplina.query.get_or_404(id)
    alunos = sorted(disciplina.alunos, key=lambda aluno: aluno.nome.lower())
    return render_template(
        "alunos_por_disciplina/lista.html",
        disciplina=disciplina,
        alunos=alunos,
    )
