from flask import render_template, redirect, url_for, flash
from app import app, db
from app.models.models import Aluno
from app.forms import AlunoForm

@app.route("/alunos")
def lista_alunos():
    alunos = Aluno.query.order_by(Aluno.nome).all()
    return render_template("alunos/lista.html", alunos=alunos)

@app.route("/alunos/novo", methods=["GET", "POST"])
def novo_aluno():
    form = AlunoForm()
    if form.validate_on_submit():
        aluno = Aluno(nome=form.nome.data.strip())
        db.session.add(aluno)
        db.session.commit()
        flash("Aluno cadastrado com sucesso!", "success")
        return redirect(url_for("lista_alunos"))
    return render_template("alunos/form.html", form=form, titulo="Novo aluno")

@app.route("/alunos/editar/<int:id>", methods=["GET", "POST"])
def editar_aluno(id):
    aluno = Aluno.query.get_or_404(id)
    form = AlunoForm(obj=aluno)
    if form.validate_on_submit():
        aluno.nome = form.nome.data.strip()
        db.session.commit()
        flash("Aluno atualizado com sucesso!", "success")
        return redirect(url_for("lista_alunos"))
    return render_template("alunos/form.html", form=form, titulo="Editar aluno")

@app.route("/alunos/deletar/<int:id>", methods=["POST"])
def deletar_aluno(id):
    aluno = Aluno.query.get_or_404(id)
    # Remove os vínculos antes de apagar o aluno.
    aluno.disciplinas.clear()
    db.session.delete(aluno)
    db.session.commit()
    flash("Aluno removido com sucesso.", "success")
    return redirect(url_for("lista_alunos"))
