from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length
from app.models.models import Aluno, Disciplina

class AlunoForm(FlaskForm):
    nome = StringField(
        "Nome do aluno",
        validators=[DataRequired(message="Informe o nome."), Length(max=100)],
    )
    submit = SubmitField("Salvar aluno")

class DisciplinaForm(FlaskForm):
    nome = StringField(
        "Nome da disciplina",
        validators=[DataRequired(message="Informe o nome."), Length(max=100)],
    )
    submit = SubmitField("Salvar disciplina")

class MatriculaForm(FlaskForm):
    aluno_id = SelectField("Aluno", coerce=int, validators=[DataRequired()])
    disciplina_id = SelectField("Disciplina", coerce=int, validators=[DataRequired()])
    submit = SubmitField("Realizar matrícula")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.aluno_id.choices = [(a.id, a.nome) for a in Aluno.query.order_by(Aluno.nome).all()]
        self.disciplina_id.choices = [(d.id, d.nome) for d in Disciplina.query.order_by(Disciplina.nome).all()]

class AlunosDisciplinaForm(FlaskForm):
    disciplina_id = SelectField("Selecione a disciplina", coerce=int, validators=[DataRequired()])
    submit = SubmitField("Ver alunos")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.disciplina_id.choices = [(d.id, d.nome) for d in Disciplina.query.order_by(Disciplina.nome).all()]
