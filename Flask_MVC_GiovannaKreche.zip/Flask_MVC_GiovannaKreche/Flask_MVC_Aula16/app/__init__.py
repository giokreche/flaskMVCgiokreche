from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from config import Config
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.config.from_object(Config)

db = SQLAlchemy(app)
migrate = Migrate(app, db)

csrf = CSRFProtect(app)

# Importar os models antes dos controllers garante que o SQLAlchemy os conheça.
from app.models import models  # noqa: E402,F401

# Os controllers ficam no final para evitar import circular.
from app.controllers import (  # noqa: E402,F401
    index_controller,
    aluno_controller,
    disciplina_controller,
    matricula_controller,
    alunos_por_disciplina_controller,
)
