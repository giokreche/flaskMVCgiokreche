from flask import render_template, redirect, url_for, flash
from app import app, db
from app.models.models import Aluno, Disciplina
from app.forms import MatriculaForm

@app.route("/matriculas")
def lista_matriculas():
    alunos = Aluno.query.order_by(Aluno.nome).all()
    return render_template("matriculas/lista.html", alunos=alunos)

@app.route("/matriculas/novo", methods=["GET", "POST"])
def nova_matricula():
    form = MatriculaForm()
    if not form.aluno_id.choices or not form.disciplina_id.choices:
        flash("Cadastre pelo menos um aluno e uma disciplina antes de matricular.", "warning")
        return redirect(url_for("lista_matriculas"))
    if form.validate_on_submit():
        aluno = db.get_or_404(Aluno, form.aluno_id.data)
        disciplina = db.get_or_404(Disciplina, form.disciplina_id.data)
        if disciplina in aluno.disciplinas:
            flash("Este aluno já está matriculado nesta disciplina.", "warning")
        else:
            aluno.disciplinas.append(disciplina)
            db.session.commit()
            flash("Matrícula realizada com sucesso!", "success")
        return redirect(url_for("lista_matriculas"))
    return render_template("matriculas/form.html", form=form)

@app.route("/matriculas/deletar/<int:aluno_id>/<int:disciplina_id>", methods=["POST"])
def deletar_matricula(aluno_id, disciplina_id):
    aluno = db.get_or_404(Aluno, aluno_id)
    disciplina = db.get_or_404(Disciplina, disciplina_id)
    if disciplina in aluno.disciplinas:
        aluno.disciplinas.remove(disciplina)
        db.session.commit()
        flash("Matrícula cancelada.", "success")
    return redirect(url_for("lista_matriculas"))
